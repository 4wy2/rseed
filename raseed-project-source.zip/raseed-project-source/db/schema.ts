/** Production Cloudflare D1 schema used by the hosted Raseed version. */
export const financeWorkspaceSql = `
CREATE TABLE IF NOT EXISTS finance_workspaces (
  user_id TEXT PRIMARY KEY NOT NULL,
  data TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL
);`;
