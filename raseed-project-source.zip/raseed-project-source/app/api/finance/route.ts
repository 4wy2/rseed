import { getChatGPTUser } from '@/app/chatgpt-auth';
import { getFinance, putFinance } from '@/lib/local-store';
import { stateSchema, validateRelations } from '@/lib/finance';
export const dynamic='force-dynamic';
export const runtime='nodejs';
const reply=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
export async function GET(){
 const user=await getChatGPTUser();if(!user)return reply({error:'يلزم تسجيل الدخول لحفظ بياناتك.'},401);
 try{const row=await getFinance(user.userId);return reply(row?{state:row.state,revision:row.revision}:{state:null,revision:0});}
 catch(e){console.error('finance-load',e);return reply({error:'تعذر تحميل بياناتك. أعد المحاولة.'},503);}
}
export async function PUT(request:Request){
 const user=await getChatGPTUser();if(!user)return reply({error:'يلزم تسجيل الدخول لحفظ بياناتك.'},401);
 if(request.headers.get('sec-fetch-site')==='cross-site')return reply({error:'طلب غير مسموح.'},403);
 if(!request.headers.get('content-type')?.includes('application/json'))return reply({error:'صيغة غير مدعومة.'},415);
 try{
  const text=await request.text();if(text.length>1800000)return reply({error:'حجم البيانات أكبر من المسموح.'},413);
  let body:any;try{body=JSON.parse(text);}catch{return reply({error:'بيانات غير صالحة.'},400);}
  const result=stateSchema.safeParse(body.state);
  if(!result.success||!Number.isSafeInteger(body.revision)||body.revision<0||!validateRelations(result.data))return reply({error:'راجع المبالغ والتواريخ والتصنيفات؛ لا تقبل العمليات المستقبلية أو المكررة.'},400);
  const saved=await putFinance(user.userId,result.data,body.revision);
  if(!saved.ok)return reply({error:'تغيرت البيانات في نافذة أخرى. أعد تحميل الصفحة قبل الحفظ.',revision:saved.revision},409);
  return reply({revision:saved.revision});
 }catch(e){console.error('finance-save',e);return reply({error:'لم يتم الحفظ. بيانات النموذج باقية؛ حاول مرة أخرى.'},503);}
}
