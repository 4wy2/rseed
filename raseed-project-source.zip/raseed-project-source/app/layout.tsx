import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'رصيد | مصروفي الجامعي',
  description: 'نظام مالي شخصي بسيط للدخل والمصاريف والالتزامات الشهرية.',
  icons: { icon: '/favicon.svg', shortcut: '/favicon.svg' },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl" suppressHydrationWarning><body>{children}</body></html>;
}
