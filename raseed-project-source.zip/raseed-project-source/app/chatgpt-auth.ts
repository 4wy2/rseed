import { headers } from 'next/headers';

export type RaseedUser = { userId: string; email?: string | null };

/**
 * Portable auth adapter.
 * - On the hosted ChatGPT version, platform headers identify the signed-in user.
 * - Locally, a stable development user is returned so the project runs immediately.
 */
export async function getChatGPTUser(): Promise<RaseedUser | null> {
  const h = await headers();
  const userId = h.get('oai-authenticated-user-id') || h.get('x-raseed-user-id');
  const email = h.get('oai-authenticated-user-email') || h.get('x-raseed-user-email');
  if (userId) return { userId, email };
  if (process.env.NODE_ENV === 'development' || process.env.RASEED_LOCAL_USER) {
    return { userId: process.env.RASEED_LOCAL_USER || 'local-user', email: 'local@raseed.test' };
  }
  return null;
}
